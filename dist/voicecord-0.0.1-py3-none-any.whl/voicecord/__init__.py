def join_voice():
    print("Joining voice channel...")