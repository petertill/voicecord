# VoiceCord | Discord voice recorder library
VoiceCord is a simple yet powerful voice recording package for Discord
